const mongoose = require('mongoose');

const noteSchema = new mongoose.Schema({
    text: { type: String, required: true },
    createdAt: { type: Date, default: Date.now },
});

const querySchema = new mongoose.Schema({
    customerName: { type: String, required: true },
    description: { type: String, required: true },
    status: { type: String, enum: ['Open', 'InProgress', 'Closed'], default: 'Open' },
    resolution: { type: String, maxlength: 100 },
    notes: [noteSchema],
    createdAt: { type: Date, default: Date.now },
});

const invoiceSchema = new mongoose.Schema({
    invoicesNumber: { type: String, required: true },
    notess: { type: String, required: true },
    summary: { type: String },
    createdAt: { type: Date, default: Date.now }
});

const query = mongoose.model('Query', querySchema);
const invoice = mongoose.model('invoice', invoiceSchema);

module.exports = { query, invoice }
