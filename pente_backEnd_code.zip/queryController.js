const Query = require('./model').query;
const invoice = require('./model').invoice;
const { GoogleGenerativeAI } = require("@google/generative-ai");
const PDFDocument = require('pdfkit');
const fs = require('fs');


import('node-fetch').then(fetchModule => {
    global.fetch = fetchModule.default;
});
// global.fetch = require("node-fetch");  // 👈 Polyfill fetch for Node.js
const getHeaders = async () => {
    const { Headers } = await import('node-fetch');
    global.Headers = Headers;
};
getHeaders();


const genAI = new GoogleGenerativeAI(process.env.genAI);

// Get all queries (with pagination)
exports.getQueries = async (req, res) => {
    try {
        const { page = 1, limit = 10, status } = req.query;
        const queryObj = status ? { status } : {};
        const skip = (page - 1) * limit;
        const queries = await Query.find(queryObj).skip(skip).limit(Number(limit));
        const total = await Query.countDocuments(queryObj);
        res.json({ queries, total });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Create a new query
exports.createQuery = async (req, res) => {
    try {
        // const queryName = await Query.findOne({ customerName: req.body.customerName });
        // if (queryName) return res.status(404).json({ message: 'Query already excits' });

        let QueryData = {};
        QueryData.customerName = req.body.customerName;
        QueryData.description = req.body.description;
        QueryData.resolution = req.body.resolution;
        console.log("Query", QueryData)

        if (QueryData.resolution && QueryData.resolution.length > 100) {
            return res.status(400).send({ message: 'Resolution exceeds 100 characters' });
        }

        const newQuery = new Query(QueryData);
        await newQuery.save();
        res.status(201).send(newQuery);
    } catch (err) {
        res.status(400).json({ error: err.messag });
    }
};

// Get a single query by ID
exports.getQueryById = async (req, res) => {
    try {
        const query = await Query.findById(req.params.id);
        if (!query) return res.status(404).json({ message: 'Query not found' });
        res.json(query);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Update query (status/resolution)
exports.updateQuery = async (req, res) => {
    try {
        const { status, resolution } = req.body;
        if (resolution && resolution.length > 100) {
            return res.status(400).json({ message: 'Resolution exceeds 100 characters' });
        }
        const query = await Query.findByIdAndUpdate(
            req.params.id,
            { status, resolution },
            { new: true }
        );
        if (!query) return res.status(404).json({ message: 'Query not found' });
        res.json(query);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Add a note
exports.addNote = async (req, res) => {
    try {
        const query = await Query.findById(req.params.id);
        if (!query) return res.status(404).json({ message: 'Query not found' });
        query.notes.push({ text: req.body.text });
        await query.save();
        res.json(query);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Delete a note
exports.deleteNote = async (req, res) => {
    try {
        const query = await Query.findById(req.params.id);
        if (!query) { return res.status(404).json({ message: 'Query not found' }); }
        // query.notes.id(req.params.noteId).remove();

        let note = query.notes.id(req.params.noteId);
        console.log("note", note)
        if (!note) { return res.status(404).json({ message: 'Note not found' }); }
        // Remove the note from the array
        query.notes = [];
        await query.save();
        console.log("query", query)
        res.json(query);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


// Get invoice
exports.getinvoice = async (req, res) => {
    try {
        const query = await invoice.find({});
        if (!query) return res.status(404).json({ message: 'Query not found' });
        res.json(query);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


// add invoice
exports.addinvoice = async (req, res) => {
    try {
        // console.log(req)
        const query = await invoice.findOne({ invoicesNumber: req.body.invoicesNumber });
        if (query) return res.status(404).json({ message: 'Invoice already excites' });
        let QueryData = {};
        QueryData.invoicesNumber = req.body.invoicesNumber;
        QueryData.notess = req.body.notess;
        const newinvoice = new invoice(QueryData);
        await newinvoice.save();
        res.json(newinvoice);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.GeminiAi = async (req, res) => {
    try {
        // console.log(req)
        // const invoiceId = req.params.invoiceId;
        const invoices = await invoice.findById(req.params.id);
        console.log("invoice", invoices)
        if (!invoice) {
            return res.status(404).json({ error: 'Invoice not found' });
        }

        // const notesText = invoice.notess.map(n => n.text).join(". ");

        const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
        const result = await model.generateContent(`Summarize these notes into a short, clear summary: ${invoices.notess}`);
        const summary = result.response.text();

        console.log("summary", summary)

        invoices.summary = summary;

        invoices.save()
        console.log("invoices", invoices)
        res.json({ summary });
    } catch (err) {
        console.error("Gemini AI Error:", err);
        res.status(500).json({ error: 'Failed to generate summary' });
    }
};



// pdf download 
exports.exportPdf = async (req, res) => {
    try {
        const query = await invoice.find({});
        if (!query || query.length === 0) {
            return res.status(404).json({ message: 'No invoices found' });
        }

        // Create a new PDF document
        const doc = new PDFDocument();

        // Set the response headers
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename=invoices.pdf');

        // Pipe the PDF stream directly to the response
        doc.pipe(res);

        // Add some content to the PDF
        doc.fontSize(20).text('Invoices List', { align: 'center' });
        doc.moveDown();

        query.forEach((invoiceItem, index) => {
            doc.fontSize(12).text(`${index + 1}. Invoice ID: ${invoiceItem._id}`);
            doc.text(`Customer Name: ${invoiceItem.invoicesNumber || 'N/A'}`);
            doc.text(`Summary: ${invoiceItem.summary || 'N/A'}`);
            doc.text(`Date: ${invoiceItem.createdAt || 'N/A'}`);
            doc.moveDown();
        });

        // Finalize the PDF and end the stream
        doc.end();

    } catch (err) {
        console.error('Error generating PDF:', err);
        res.status(500).json({ error: err.message });
    }
};
