const express = require('express');
const app = express();
const connectDB = require('./db');
const PORT = process.env.PORT;
const cors = require('cors');
const controller = require('./queryController');


// Connect to MongoDB
connectDB();

const allowedOrigins = ['http://localhost:4200', 'http://0.0.0.0:8080'];

app.use(cors({
    origin: function (origin, callback) {
        if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    }
}));

// Express middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'))



app.use(cors());

// query
app.get('/api/queries', controller.getQueries);
app.post('/api/queries', controller.createQuery);
app.get('/api/queries/:id', controller.getQueryById);
app.put('/api/queries/:id', controller.updateQuery);
app.post('/api/queries/:id/notes', controller.addNote);
app.delete('/api/queries/:id/notes/:noteId', controller.deleteNote);

// invoice bugfix/invoice-note
app.post('/bugfix/invoice-note', controller.addinvoice);
app.get('/bugfix/invoice-note', controller.getinvoice);

// ai
app.post('/api/invoices/:id', controller.GeminiAi);


// exportPdf
app.get('/api/invoices/export/pdf', controller.exportPdf);


// Server start
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});