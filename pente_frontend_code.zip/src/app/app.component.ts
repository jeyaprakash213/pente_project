


import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
// export class AppComponent {
//   title = 'my-app';
// }
export class AppComponent implements OnInit {



  getInStockDatas: any[] = [];
  queryArray: any;
  selectedQueryId: any;
  newResolution: any;
  newDescription: any;
  newCustomerName: any;
  limit: any;
  page: any;
  updatedResolution: any;
  selectedStatus: any;
  updatedStatus: any;
  newNote: any;
  newNotes: { [key: string]: string } = {};
  invoices: any;
  summary: any;
  notess: any;
  invoicesNumber: any;

  constructor(private http: HttpClient) {
    this.getAllQueries();
    this.getInvoices()
  }
  ngOnInit(): void {


  }


  selectQuery(id: string) {
    this.selectedQueryId = id;
  }

  // addNote(queryId: string) {
  //   const noteContent = this.newNotes[queryId];
  //   if (!noteContent || noteContent.trim() === '') {
  //     alert('Please enter a note');
  //     return;
  //   }

  //   this.http.post(`http://localhost:5000/api/queries/${queryId}/notes`, {
  //     text: noteContent
  //   }).subscribe((resultData: any) => {
  //     console.log("Note Added", resultData);
  //     this.getAllQueries(); // refresh the list
  //     this.newNotes[queryId] = ''; // clear input
  //   });
  // }

  addNote(queryId: string) {
    const noteContent = this.newNotes[queryId]?.trim();

    if (!noteContent) {
      alert('Please enter a note');
      return;
    }

    // Find the query by ID
    const query = this.queryArray.find((q: { _id: string; }) => q._id === queryId);
    if (!query) {
      alert('Query not found');
      return;
    }

    // Check if there's already a note
    if (query.notes && query.notes.length > 0) {
      alert('A note already exists for this query. Please delete it before adding a new one.');
      return;
    }

    // If no existing note, proceed to add
    this.http.post(`http://localhost:5000/api/queries/${queryId}/notes`, {
      text: noteContent
    }).subscribe(
      (resultData: any) => {
        console.log("Note Added", resultData);
        this.getAllQueries(); // refresh the list
        this.newNotes[queryId] = ''; // clear the input field
      },
      (error) => {
        console.error('Error adding note:', error);
        alert('Failed to add note. Please try again.');
      }
    );
  }


  deleteNote(queryId: string, noteId: string) {
    this.http.delete(`http://localhost:5000/api/queries/${queryId}/notes/${noteId}`)
      .subscribe((resultData: any) => {
        console.log("Note Deleted", resultData);
        this.getAllQueries(); // refresh the list
      });
  }




  getAllQueries() {
    console.log("jjjjjjjjjjj")
    // this.limit = 2
    let url = `http://localhost:5000/api/queries?page=${this.page}&limit=${this.limit}`;
    if (this.selectedStatus) {
      url += `&status=${this.selectedStatus}`;
    }
    this.http.get(url)
      .subscribe((resultData: any) => {
        console.log("resultData", resultData);
        this.queryArray = resultData.queries;
      });

  }



  saveQuery() {

    let bodyData = {
      "customerName": this.newCustomerName,
      "description": this.newDescription,
      // "status": 'Open',
      "resolution": this.newResolution
    };

    console.log("bodyData", bodyData)

    this.http.post("http://localhost:5000/api/queries", bodyData).subscribe((resultData: any) => {
      console.log("resultData", resultData);
      this.getAllQueries()
      this.clearFields()
      alert("Query add Successfully")
    });
  }

  saveInvoice() {

    let bodyData = {
      "invoicesNumber": this.invoicesNumber,
      "notess": this.notess,

    };

    console.log("bodyData", bodyData)

    this.http.post("http://localhost:5000/bugfix/invoice-note", bodyData).subscribe((resultData: any) => {
      console.log("resultData", resultData);
      this.getInvoices()
      this.invoicesNumber = '';
      this.notess = '';
      alert("Invoice add Successfully")
    });
  }



  clearFields() {
    this.newCustomerName = '';
    this.newDescription = '';
    this.newResolution = '';
  }

  nextPage() {
    this.page++;
    this.getAllQueries();
  }

  prevPage() {
    if (this.page > 1) {
      this.page--;
      this.getAllQueries();
    }
  }

  cancelUpdate() {
    this.selectedQueryId = null;
  }


  updateQuery() {
    console.log(this.selectedQueryId)
    if (this.selectedQueryId) {
      const bodyData = {
        "status": this.updatedStatus,
        "resolution": this.updatedResolution
      };

      console.log("bodyData", bodyData)
      this.http.put(`http://localhost:5000/api/queries/${this.selectedQueryId}`, bodyData)
        .subscribe((res) => {
          console.log("res", res)
          this.getAllQueries();
          this.selectedQueryId = null;
          alert("Query updated Successfully")
        });
    }
  }


  startUpdate(query: any) {
    this.selectedQueryId = query._id;
    this.updatedResolution = query.resolution;
  }



  filterByStatus() {
    this.page = 1;
    this.limit = 10;
    this.getAllQueries();
  }




  getInvoices() {
    this.http.get<any[]>('http://localhost:5000/bugfix/invoice-note').subscribe(data => {
      this.invoices = data;
    });
  }

  generateSummary(queryId: string) {
    this.http.post<{ summary: string }>(`http://localhost:5000/api/invoices/${queryId}`, {})
      .subscribe(response => {
        alert('Summary Generated!');
        this.getInvoices(); // refresh to show updated summary
      });
  }


  // exportPDF() {
  //   window.open('http://localhost:5000/api/invoices/export/pdf', '_blank');
  // }

  exportPDF() {
    // alert('PDF export not implemented — backend PDF endpoint needs to be added.');
    alert('PDF export not implemented — backend PDF endpoint needs to be added.');
  }

  // printPDF() {
  //   const printContents = document.getElementById('print-section')!.innerHTML;
  //   const popupWin = window.open('', '_blank', 'width=900,height=600');
  //   popupWin!.document.open();
  //   popupWin!.document.write(`
  //     <html>
  //       <head>
  //         <title>Invoice Notes Report</title>
  //         <style>
  //           body { font-family: Arial, sans-serif; margin: 20px; }
  //           table { width: 100%; border-collapse: collapse; }
  //           th, td { border: 1px solid #ddd; padding: 8px; }
  //           th { background-color: #f0f0f0; }
  //           ul { margin: 0; padding-left: 20px; }
  //         </style>
  //       </head>
  //       <body onload="window.print();window.close()">
  //         ${printContents}
  //       </body>
  //     </html>
  //   `);
  //   popupWin!.document.close();
  // }



}